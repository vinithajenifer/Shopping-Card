<?php 
	include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>index page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
  integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <link href="https://fonts.googleapis.com/css?family=Titillium+Web&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
 
<nav class="navbar navbar-expand-md navbar-light bg-info">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">ICY BUTTERFLY🦋 COSMATICS💄</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
      <button><a href="logout.php">LOGOUT</a></button>
    </div>
  </div>
</nav>

<div class="container" >
  <div class="row ">
 
			<h1>VI WORLD</h1>
     
			<?php   
			$sql="select * from cosmetics";
			$res=$conn->query($sql);
			if($res->num_rows>0)
			{
				while($row=$res->fetch_assoc())
				{
			echo  '
   <div class="col-md-3" width=150px height=150px >
   <div class="card" >
     <img src="image/'. $row['image'].'" alt="" width="150px" height="150px" class="img-responsive" >
     
     <div class="card-body">
     <p class="text-center"> <strong> ' .$row['product name'].'</strong></p>
   <h4 class="text-danger text-center"> Rs.'. $row['product price'].'</h4>
   <p><a href="view.php?id='. $row['id'] .'" class="btn btn-success">View Details</a></p>
   </div>
   </div>
   </div>
   ';
   
				}
			}
			?>
  
</div>
</div>

</body>
</html>