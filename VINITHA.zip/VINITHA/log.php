<?php
// session_start();

// include "connection.php";

// if (isset($_POST['signin'])) {
//     $username_email = mysqli_real_escape_string($db, $_post['username']);
//     $password = mysqli_real_escape_string($db, $_POST['password']);
//     $sql_fetch_user ="select * from register where username='$username_email' or e"
// }




include "connection.php";

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $username = $_POST["username"];
   
    $password = $_POST["password"];
    
    // Sanitize inputs before using them in a query to prevent SQL injection
    
    // You might want to use prepared statements instead of directly embedding values in the query
    
    $sql = "SELECT * FROM `register` WHERE username='{$username}' AND password='{$password}'";
    
    $query_run = mysqli_query($conn, $sql);
    $result = mysqli_num_rows($query_run) > 0;

    if ($result) {
        $row = mysqli_fetch_assoc($query_run);
        session_start(); 
        $_SESSION["id"] = $row["id"];
        $_SESSION["username"] = $row["username"];
        $_SESSION["password"] = $row["password"];
        
        // Avoid storing passwords in session variables
        // $_SESSION["password"] = $row["password"];
        header("location: index.php");
    } else {
        echo "<div class='msg-danger'>Invalid Login!!!</div>";
    }
}
?>
