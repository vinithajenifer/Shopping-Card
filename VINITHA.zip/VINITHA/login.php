
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <style>
body  {
    
    background: url(./image/Cosmetic\ foundation\ cream\ background\ \(1\).jpg); 
   
  
    
 }

 h2{
    text-align:center;
   color: black;
}

form{
    
    display: flex;
    flex-direction: column;  
    height: 150px;
    width: 280px;
    border: 1px solid rgb(27, 5, 5); 
    align-items: center;
    margin: auto;
    margin-top: 20px;
    padding: 60px;
    box-shadow: inset -5PX, -5PX rgba(0,0, 0, 0.5);
    border-radius: 25px; 
 
}

button{
    text-align: center; 
    border-radius:10px ;
    background-color: rgba(0, 0, 0, 0.5); 
    width: 15%;
    color: white;
    font-size: 1rem; 
    margin-top: 250px; 
    margin-inline-start: -200px;
    transition:50px ;
    align-items: center;
    position: absolute;
    margin-left: 2px;
}
</style>
    <body>
        <h2>LOGIN</h2>
        <form class="form" action="log.php"  method="post" autocomplete="off"> 

      <!-- <label for="id"><b>ID</b></label>
      <input type="id" placeholder="Enter Your Id" name="id" required><br> -->

      <label for="username"><b>USERNAME</b></label>
      <input type="text" placeholder="Enter Username" name="username" required><br>


     
      <label for="password"><b>PASSWORD</b></label>
      <input type="password" placeholder="Enter Password" name="password" required><br>
      <button type="submit" name="submit">LOGIN </button>
      </form>



    </body>
    </html>
  

   