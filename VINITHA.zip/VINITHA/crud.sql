-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 05, 2023 at 10:11 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pname` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `qty` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cosmetics`
--

DROP TABLE IF EXISTS `cosmetics`;
CREATE TABLE IF NOT EXISTS `cosmetics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image` varchar(20) NOT NULL,
  `product name` varchar(30) NOT NULL,
  `product price` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cosmetics`
--

INSERT INTO `cosmetics` (`id`, `image`, `product name`, `product price`) VALUES
(1, 'image 14.jpg', 'LIPSTICKS', '500'),
(2, 'image 13', 'CONCEALER', '450'),
(3, 'IMG1', 'BRUSHES', '350'),
(4, 'IMG2', 'MAKEUP KIDS', '2000'),
(5, 'image 8', 'FOUNDATION', '300'),
(6, 'image 9', 'HIGHLIGHTER', '280'),
(7, 'image 11', 'BLUSH', '360'),
(8, 'image 15', 'EYE ACCESSORIES ', '800'),
(9, 'image 5', 'EYESHADOWS', '300'),
(10, 'image.jpg', 'FACE POWDER', '500'),
(11, 'image 2', 'CREAMS', '250'),
(12, 'IMG3', 'BRONZER', '550');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`) VALUES
(1, 'vinitha', 'vinitha@gmail.com', 'vinitha'),
(2, 'jeni', 'jeni@gmail.com', 'jeni'),
(3, 'isai', 'isai@gmail.com', 'isai'),
(4, 'isai', 'isai77@gmail.com', 'isai');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
