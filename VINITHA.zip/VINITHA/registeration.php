<?php
include 'connection.php';
if(isset($_POST['submit'])){
    extract($_POST);
    $sql="insert into `register`(username,email,password) values ('$username','$email','$password')";
    $result=$conn->query($sql);
    if($result){
        echo "<script>alert(insert successfully)</script>";
        header ("location:login.php");
    }else{
        die("error:".$mysql->error());
    }
}
?>

 
 
 
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
    <style>
*  {
    
    background: url(./image/Face\ Cream.jpg)
    
}

h2{
    text-align:center;
   color: black;
}

label{
    color: white;
}
.form{
    
    display: flex;
    flex-direction: column;  
    height: 300px;
    width: 400px;
    border: 1px solid rgb(27, 5, 5); 
    align-items: center;
    margin: auto;
    margin-top: 20px;
    padding: 60px;
    box-shadow: inset -5PX, -5PX rgba(0,0, 0, 0.5);
    border-radius: 25px; 
 
}

button{
    text-align: center; 
    border-radius:10px ;
    background-color: rgba(0, 0, 0, 0.5); 
    width: 15%;
    color: white;
    font-size: 1rem; 
    margin-top: 270px; 
    margin-inline-start: -200px;
    transition:50px ;
    align-items: center;
    position: absolute;
    margin-left: 2px;
}
</style>
    <body >
        
        <h2>REGISTERATION</h2>
        <form class="form" method="post" autocomplete="off"> 

      <!-- <label for="id"><b>ID</b></label>
      <input type="id" placeholder="Enter Your Id" name="id" required><br> -->

      <label for="uname"><b>USERNAME</b></label>
      <input type="text" placeholder="Enter Username" name="username" required><br>


      <label for="email"><b>EMAIL</b></label>
      <input type="email" placeholder="Enter email" name="email" required><br>

      <label for="psw"><b>PASSWORD</b></label>
      <input type="password" placeholder="Enter Password" name="password" required><br>
      <button type="submit" name="submit">SUBMIT</button>
      </form>



    </body>
    </html>
    

</body>

</html>

 