<?php
$servername ="localhost";
$username ="root";
$password = "";
$database = "crud";

$conn= new mysqli($servername,$username,$password,$database);

if($conn->connect_error){

   die("connection faild:".$conn->connect_error);
}

// $conn = mysqli_connect("localhost","root","","curd")
?>